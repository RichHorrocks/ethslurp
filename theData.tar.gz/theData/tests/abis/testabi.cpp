#include "daolib.h"

int main(int argc, char *argv[])
{
	if (argc!=2)
	{
		printf("%d args. Need start / stop\n", argc);
		exit(0);
	}
	int test = toLong(argv[1]);
	CFunction::registerClass();
	CParameter::registerClass();
	CAccount::registerClass();
	CTransaction::registerClass();
	for (int i=test;i<=test;i++)
	{
		SFString contents = asciiFileToString(asString(i)+".json");
		printf("%d.json\n", i);
		printf("%s\n", (const char*)contents);
		char *p = (char *)(const char*)contents;
		while (p && *p)
		{
			CFunction func;SFInt32 nFields=0;
			p = func.parseJson(p,nFields);
			if (nFields)
				printf("%s\n", (const char*)func.Format());
		}
	}
}

//---------------------------------------------------------------------------------------------------
CParams params[] =
{
};
SFInt32 nParams = sizeof(params) / sizeof(CParams);
